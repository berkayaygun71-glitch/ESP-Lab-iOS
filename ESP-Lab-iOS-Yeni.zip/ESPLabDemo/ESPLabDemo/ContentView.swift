import SwiftUI

@main
struct ESPLabDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

private enum Team {
    case ally
    case enemy

    var color: Color {
        switch self {
        case .ally: return Color(red: 0.22, green: 0.78, blue: 1.00)
        case .enemy: return Color(red: 1.00, green: 0.31, blue: 0.34)
        }
    }

    var title: String {
        switch self {
        case .ally: return "DOST"
        case .enemy: return "RAKİP"
        }
    }
}

private struct DemoUnit: Identifiable, Equatable {
    let id: Int
    let name: String
    let role: String
    let team: Team
    let x: CGFloat
    let y: CGFloat
    let health: Int
}

struct ContentView: View {
    @State private var showEnemies = true
    @State private var showAllies = true
    @State private var fogEnabled = false
    @State private var showWalls = true
    @State private var selectedID = 1

    private let units: [DemoUnit] = [
        DemoUnit(id: 1, name: "NOVA", role: "Keskin nişancı", team: .enemy, x: 0.72, y: 0.27, health: 84),
        DemoUnit(id: 2, name: "VEX", role: "Tank", team: .enemy, x: 0.57, y: 0.61, health: 62),
        DemoUnit(id: 3, name: "KAI", role: "Suikastçı", team: .enemy, x: 0.29, y: 0.43, health: 100),
        DemoUnit(id: 4, name: "MIRA", role: "Destek", team: .ally, x: 0.22, y: 0.76, health: 91),
        DemoUnit(id: 5, name: "ORION", role: "Savaşçı", team: .ally, x: 0.81, y: 0.78, health: 73)
    ]

    private var visibleUnits: [DemoUnit] {
        units.filter { $0.team == .enemy ? showEnemies : showAllies }
    }

    private var selectedUnit: DemoUnit? {
        units.first { $0.id == selectedID }
    }

    var body: some View {
        ZStack {
            Color(red: 0.035, green: 0.055, blue: 0.085).ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    header
                    mapPanel
                    statsRow
                    controlsPanel

                    if let unit = selectedUnit {
                        selectedUnitPanel(unit)
                    }

                    Text("Bağımsız demo uygulaması • Gerçek Mobile Legends verisi okumaz ve oyuna bağlanmaz.")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.42))
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity)
                        .padding(.top, 2)
                        .padding(.bottom, 18)
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)
            }
        }
        .preferredColorScheme(.dark)
    }

    private var header: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 3) {
                Text("TACTICAL TOOLS")
                    .font(.system(size: 10, weight: .heavy, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(Color.cyan.opacity(0.85))
                Text("ESP LAB")
                    .font(.system(size: 30, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
            }

            Spacer()

            HStack(spacing: 6) {
                Circle()
                    .fill(Color.green)
                    .frame(width: 7, height: 7)
                Text("DEMO MODE")
                    .font(.system(size: 10, weight: .heavy, design: .rounded))
                    .tracking(0.8)
            }
            .padding(.horizontal, 11)
            .padding(.vertical, 8)
            .background(Color.green.opacity(0.12), in: Capsule())
            .overlay(Capsule().stroke(Color.green.opacity(0.3), lineWidth: 1))
        }
    }

    private var mapPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("BATTLEFIELD")
                        .font(.system(size: 14, weight: .heavy, design: .rounded))
                        .tracking(1.1)
                        .foregroundStyle(.white)
                    Text("Örnek harita • 5 birim")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.48))
                }
                Spacer()
                Text("SIMULATED")
                    .font(.system(size: 9, weight: .heavy, design: .rounded))
                    .tracking(1)
                    .foregroundStyle(Color.cyan)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 6)
                    .background(Color.cyan.opacity(0.12), in: Capsule())
            }

            GeometryReader { geometry in
                ZStack {
                    BattlefieldCanvas(showWalls: showWalls)

                    ForEach(visibleUnits) { unit in
                        Button {
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.72)) {
                                selectedID = unit.id
                            }
                        } label: {
                            UnitMarker(unit: unit, isSelected: selectedID == unit.id)
                        }
                        .buttonStyle(.plain)
                        .position(
                            x: geometry.size.width * unit.x,
                            y: geometry.size.height * unit.y
                        )
                    }

                    if fogEnabled {
                        RoundedRectangle(cornerRadius: 18)
                            .fill(Color.black.opacity(0.58))
                            .overlay {
                                VStack(spacing: 7) {
                                    Image(systemName: "cloud.fog.fill")
                                        .font(.system(size: 25, weight: .semibold))
                                    Text("FOG OF WAR AÇIK")
                                        .font(.system(size: 11, weight: .heavy, design: .rounded))
                                        .tracking(1.2)
                                    Text("Bu katman yalnızca demo haritasını etkiler")
                                        .font(.system(size: 9, weight: .medium))
                                        .foregroundStyle(.white.opacity(0.65))
                                }
                                .foregroundStyle(.white.opacity(0.9))
                            }
                            .allowsHitTesting(false)
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .stroke(Color.white.opacity(0.09), lineWidth: 1)
                }
            }
            .frame(height: 315)

            HStack(spacing: 14) {
                legendDot(color: Team.enemy.color, label: "Rakip")
                legendDot(color: Team.ally.color, label: "Dost")
                Spacer()
                Text("İşaretçiye dokun")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(.white.opacity(0.4))
            }
        }
        .padding(14)
        .background(Color(red: 0.075, green: 0.10, blue: 0.145), in: RoundedRectangle(cornerRadius: 22))
        .overlay {
            RoundedRectangle(cornerRadius: 22)
                .stroke(Color.white.opacity(0.07), lineWidth: 1)
        }
    }

    private var statsRow: some View {
        HStack(spacing: 10) {
            StatCard(value: "\(units.filter { $0.team == .enemy }.count)", label: "RAKİP", color: Team.enemy.color)
            StatCard(value: "\(units.filter { $0.team == .ally }.count)", label: "DOST", color: Team.ally.color)
            StatCard(value: "\(visibleUnits.count)", label: "GÖRÜNÜR", color: Color.yellow)
        }
    }

    private var controlsPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("GÖRÜNÜM AYARLARI")
                .font(.system(size: 12, weight: .heavy, design: .rounded))
                .tracking(1.1)
                .foregroundStyle(.white.opacity(0.82))

            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ControlTile(
                    title: "Rakip ESP",
                    subtitle: "Rakip işaretçileri",
                    icon: "scope",
                    tint: Team.enemy.color,
                    isOn: showEnemies
                ) { showEnemies.toggle() }

                ControlTile(
                    title: "Dost ESP",
                    subtitle: "Dost işaretçileri",
                    icon: "person.2.fill",
                    tint: Team.ally.color,
                    isOn: showAllies
                ) { showAllies.toggle() }

                ControlTile(
                    title: "Fog of War",
                    subtitle: "Sis katmanı",
                    icon: "cloud.fog.fill",
                    tint: Color.purple,
                    isOn: fogEnabled
                ) { fogEnabled.toggle() }

                ControlTile(
                    title: "Duvarlar",
                    subtitle: "Harita engelleri",
                    icon: "square.3.layers.3d",
                    tint: Color.orange,
                    isOn: showWalls
                ) { showWalls.toggle() }
            }
        }
        .padding(14)
        .background(Color(red: 0.075, green: 0.10, blue: 0.145), in: RoundedRectangle(cornerRadius: 22))
        .overlay {
            RoundedRectangle(cornerRadius: 22)
                .stroke(Color.white.opacity(0.07), lineWidth: 1)
        }
    }

    private func selectedUnitPanel(_ unit: DemoUnit) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("SEÇİLİ BİRİM")
                    .font(.system(size: 12, weight: .heavy, design: .rounded))
                    .tracking(1.1)
                    .foregroundStyle(.white.opacity(0.7))
                Spacer()
                Text(unit.team.title)
                    .font(.system(size: 9, weight: .heavy, design: .rounded))
                    .tracking(0.8)
                    .foregroundStyle(unit.team.color)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 5)
                    .background(unit.team.color.opacity(0.12), in: Capsule())
            }

            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(unit.team.color.opacity(0.15))
                    Circle().stroke(unit.team.color.opacity(0.55), lineWidth: 1.5)
                    Image(systemName: unit.team == .enemy ? "scope" : "person.fill")
                        .font(.system(size: 21, weight: .bold))
                        .foregroundStyle(unit.team.color)
                }
                .frame(width: 48, height: 48)

                VStack(alignment: .leading, spacing: 3) {
                    Text(unit.name)
                        .font(.system(size: 17, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text(unit.role)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.52))
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text("\(unit.health)%")
                        .font(.system(size: 17, weight: .black, design: .rounded))
                        .foregroundStyle(unit.health > 50 ? Color.green : Color.orange)
                    Text("CAN")
                        .font(.system(size: 9, weight: .heavy))
                        .tracking(1)
                        .foregroundStyle(.white.opacity(0.42))
                }
            }

            GeometryReader { proxy in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.08))
                    Capsule()
                        .fill(unit.health > 50 ? Color.green : Color.orange)
                        .frame(width: proxy.size.width * CGFloat(unit.health) / 100)
                }
            }
            .frame(height: 6)
        }
        .padding(14)
        .background(Color(red: 0.075, green: 0.10, blue: 0.145), in: RoundedRectangle(cornerRadius: 22))
        .overlay {
            RoundedRectangle(cornerRadius: 22)
                .stroke(unit.team.color.opacity(0.22), lineWidth: 1)
        }
    }

    private func legendDot(color: Color, label: String) -> some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 7, height: 7)
            Text(label)
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(.white.opacity(0.7))
        }
    }
}

private struct UnitMarker: View {
    let unit: DemoUnit
    let isSelected: Bool

    var body: some View {
        VStack(spacing: 4) {
            ZStack {
                if isSelected {
                    Circle()
                        .stroke(unit.team.color.opacity(0.65), lineWidth: 2)
                        .frame(width: 43, height: 43)
                }
                Circle()
                    .fill(unit.team.color.opacity(0.18))
                    .frame(width: 32, height: 32)
                Circle()
                    .fill(unit.team.color)
                    .frame(width: 12, height: 12)
                Image(systemName: unit.team == .enemy ? "scope" : "person.fill")
                    .font(.system(size: 10, weight: .black))
                    .foregroundStyle(.white)
            }

            Text(unit.name)
                .font(.system(size: 9, weight: .black, design: .rounded))
                .tracking(0.5)
                .foregroundStyle(.white)
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(Color.black.opacity(0.68), in: Capsule())
                .overlay(Capsule().stroke(unit.team.color.opacity(0.55), lineWidth: 0.8))
        }
        .scaleEffect(isSelected ? 1.08 : 1.0)
        .shadow(color: unit.team.color.opacity(0.28), radius: isSelected ? 9 : 4)
    }
}

private struct StatCard: View {
    let value: String
    let label: String
    let color: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(value)
                .font(.system(size: 22, weight: .black, design: .rounded))
                .foregroundStyle(color)
            Text(label)
                .font(.system(size: 9, weight: .heavy, design: .rounded))
                .tracking(1)
                .foregroundStyle(.white.opacity(0.45))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(Color(red: 0.075, green: 0.10, blue: 0.145), in: RoundedRectangle(cornerRadius: 16))
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.white.opacity(0.06), lineWidth: 1)
        }
    }
}

private struct ControlTile: View {
    let title: String
    let subtitle: String
    let icon: String
    let tint: Color
    let isOn: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 9) {
                Image(systemName: icon)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(isOn ? tint : .white.opacity(0.35))
                    .frame(width: 30, height: 30)
                    .background((isOn ? tint : Color.white).opacity(0.10), in: RoundedRectangle(cornerRadius: 9))

                VStack(alignment: .leading, spacing: 3) {
                    Text(title)
                        .font(.system(size: 11, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.system(size: 9, weight: .medium))
                        .foregroundStyle(.white.opacity(0.42))
                }

                Spacer(minLength: 0)

                Circle()
                    .fill(isOn ? tint : Color.white.opacity(0.18))
                    .frame(width: 7, height: 7)
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(isOn ? tint.opacity(0.075) : Color.black.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
            .overlay {
                RoundedRectangle(cornerRadius: 14)
                    .stroke(isOn ? tint.opacity(0.28) : Color.white.opacity(0.06), lineWidth: 1)
            }
        }
        .buttonStyle(.plain)
    }
}

private struct BattlefieldCanvas: View {
    let showWalls: Bool

    var body: some View {
        Canvas { context, size in
            let bounds = CGRect(origin: .zero, size: size)
            context.fill(Path(bounds), with: .color(Color(red: 0.055, green: 0.16, blue: 0.15)))

            // Subtle map grid
            var grid = Path()
            for index in 1..<8 {
                let x = size.width * CGFloat(index) / 8
                let y = size.height * CGFloat(index) / 8
                grid.move(to: CGPoint(x: x, y: 0))
                grid.addLine(to: CGPoint(x: x, y: size.height))
                grid.move(to: CGPoint(x: 0, y: y))
                grid.addLine(to: CGPoint(x: size.width, y: y))
            }
            context.stroke(grid, with: .color(.white.opacity(0.055)), lineWidth: 1)

            // River running diagonally through the map
            var river = Path()
            river.move(to: CGPoint(x: size.width * 0.05, y: size.height * 0.57))
            river.addCurve(
                to: CGPoint(x: size.width * 0.95, y: size.height * 0.34),
                control1: CGPoint(x: size.width * 0.36, y: size.height * 0.76),
                control2: CGPoint(x: size.width * 0.60, y: size.height * 0.16)
            )
            context.stroke(river, with: .color(Color(red: 0.12, green: 0.34, blue: 0.42).opacity(0.8)), style: StrokeStyle(lineWidth: 23, lineCap: .round))
            context.stroke(river, with: .color(Color(red: 0.23, green: 0.48, blue: 0.53).opacity(0.55)), style: StrokeStyle(lineWidth: 2, lineCap: .round))

            // Lane paths
            var lanes = Path()
            lanes.move(to: CGPoint(x: size.width * 0.08, y: size.height * 0.12))
            lanes.addLine(to: CGPoint(x: size.width * 0.88, y: size.height * 0.88))
            lanes.move(to: CGPoint(x: size.width * 0.12, y: size.height * 0.90))
            lanes.addLine(to: CGPoint(x: size.width * 0.88, y: size.height * 0.10))
            context.stroke(lanes, with: .color(Color.white.opacity(0.12)), style: StrokeStyle(lineWidth: 8, lineCap: .round))

            // Jungle zones
            let bushes: [(CGFloat, CGFloat, CGFloat, CGFloat)] = [
                (0.08, 0.25, 0.18, 0.13), (0.72, 0.10, 0.19, 0.12),
                (0.37, 0.79, 0.20, 0.12), (0.73, 0.56, 0.17, 0.15),
                (0.12, 0.62, 0.13, 0.12)
            ]
            for bush in bushes {
                let rect = CGRect(
                    x: size.width * bush.0,
                    y: size.height * bush.1,
                    width: size.width * bush.2,
                    height: size.height * bush.3
                )
                context.fill(Path(roundedRect: rect, cornerRadius: 10), with: .color(Color(red: 0.10, green: 0.29, blue: 0.18).opacity(0.8)))
                context.stroke(Path(roundedRect: rect, cornerRadius: 10), with: .color(Color.green.opacity(0.13)), lineWidth: 1)
            }

            // Team bases
            let baseSize = CGSize(width: 34, height: 34)
            let allyBase = CGRect(x: size.width * 0.04, y: size.height * 0.82, width: baseSize.width, height: baseSize.height)
            let enemyBase = CGRect(x: size.width * 0.88, y: size.height * 0.05, width: baseSize.width, height: baseSize.height)
            context.fill(Path(ellipseIn: allyBase), with: .color(Team.ally.color.opacity(0.25)))
            context.stroke(Path(ellipseIn: allyBase), with: .color(Team.ally.color.opacity(0.8)), lineWidth: 2)
            context.fill(Path(ellipseIn: enemyBase), with: .color(Team.enemy.color.opacity(0.25)))
            context.stroke(Path(ellipseIn: enemyBase), with: .color(Team.enemy.color.opacity(0.8)), lineWidth: 2)

            if showWalls {
                var walls = Path()
                walls.move(to: CGPoint(x: size.width * 0.39, y: size.height * 0.28))
                walls.addLine(to: CGPoint(x: size.width * 0.49, y: size.height * 0.34))
                walls.move(to: CGPoint(x: size.width * 0.58, y: size.height * 0.67))
                walls.addLine(to: CGPoint(x: size.width * 0.70, y: size.height * 0.72))
                walls.move(to: CGPoint(x: size.width * 0.22, y: size.height * 0.48))
                walls.addLine(to: CGPoint(x: size.width * 0.31, y: size.height * 0.54))
                context.stroke(walls, with: .color(Color.orange.opacity(0.9)), style: StrokeStyle(lineWidth: 5, lineCap: .round))
            }
        }
    }
}
