# ESP Lab Demo (iOS)

Bu proje, SwiftUI ile hazırlanmış bağımsız bir iOS arayüz prototipidir.

## İçerik
- Demo minimap / savaş alanı görünümü
- Örnek dost ve rakip işaretçileri
- İşaretçiye dokununca birim ayrıntısı
- Rakip ESP ve Dost ESP görünürlük anahtarları
- Fog of War demo katmanı
- Harita duvarlarını göster/gizle kontrolü

## Önemli sınır
Bu uygulama Mobile Legends'a bağlanmaz; oyun belleğini, ağ trafiğini veya gerçek maç verilerini okumaz. Her şey uygulama içinde tanımlanmış sentetik demo verisidir.

## Xcode ile açma
1. ZIP dosyasını Mac'e çıkar.
2. `ESPLabDemo.xcodeproj` dosyasını Xcode ile aç.
3. Bir iPhone simülatörü veya bağlı iPhone seç.
4. Signing & Capabilities bölümünde kendi Apple Developer/Personal Team hesabını seç.
5. Run düğmesine bas.

## IPA alma
Xcode'da `Product > Archive` yolunu izle. Ardından Organizer içinden dağıtım / dışa aktarma seçeneklerini kullanarak imzalı IPA oluşturabilirsin. Ücretsiz Apple hesabıyla cihaz üzerinde yükleme ve imzalama kısıtları olabilir.
